import { ChatContext } from '@md-modules/chat';
import React, { useState } from 'react';
import { MessageCard } from '../messageCard';
import { WrapperRightContent, Input, Content } from './views';

export const RightContent = () => {
  
  // const [submitValue, setSubmitValue] = useState('');

  const { handleChange, handleSubmit, inputValue, correspondence } = React.useContext(ChatContext);

  const def = {
    id: '1m',
    users: {
      firstId: '1u',
      secondId: '2u'
    },

    messages: [
      {
        id: '1u',
        message: 'Привет'
      },
      {
        id: '2u',
        message: 'Hello2'
      },
      {
        id: '1u',
        message: 'Как дела'
      },
      {
        id: '2u',
        message: 'Норм, сам как?'
      },
      {
        id: '1u',
        message: 'Ниче, норм'
      },
      {
        id: '2u',
        message: 'У меня тож норм'
      }
    ]
  };

  

  //  <UserAvatar url={urlImg} />

  return (
    <WrapperRightContent>
      <Content>
        {correspondence[0].message.map((item, index) => {
          return <MessageCard key={index} id={item.id} message={item.message} />;
        })}
      </Content>
      <form onSubmit={handleSubmit}>
        <Input type={'text'} onChange={handleChange} value={inputValue} />
      </form>
    </WrapperRightContent>
  );
};
