// type

// components

// views
import React, { useState } from 'react';
import { RightContent } from './components/rightContent';
import { LeftContent } from './components/leftContent';
import { WrapperChatPage } from './views';
import { ContextChat, StateChatType, CorrespondenceType } from '@md-modules/shared/types/chat';
import { User } from './constants/users';

export const ChatContext = React.createContext<ContextChat>({
  stateChat: [],
  inputValue: '',
  handleStateChat: () => {},
  correspondence: [],
  handleCorrespondence: () => {},
  handleChange: () => {},
  handleSubmit: () => {}
});
const defCor = [
  {
    id: '1dc',
    users: {
      firstId: '1dc',
      secondId: '2cd'
    },
    message: [
      {
        id: '2u',
        message: 'Hello'
      }
    ]
  },
  {
    id: '2dc',
    users: {
      firstId: '3dc',
      secondId: '2cd'
    },
    message: [
      {
        id: '3dc',
        message: 'string'
      }
    ]
  }
];

export const ChatPage = () => {
  const [stateUser, setStateUser] = useState<StateChatType[]>(User);
  const [correspondence, setCorrespondence] = useState<CorrespondenceType[]>(defCor);
  const [inputValue, setInputValue] = useState('');

  const defo = {
    id: '1d',
    name: 'TRON',
    urlImg: 'no-img',
    isActive: false
  };

  // console.log(stateChat);
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.currentTarget.value;
    // const currentItem = correspondence.find((item) => item.id === id) || defCor;
    //  const currentIndex = correspondence.findIndex((item) => item.id === id);
    // console.log(inputValue);
    // console.log(correspondence);
    // console.log(correspondence);
    // ({ ...correspondence, message: [...correspondence.message, { id: '1u', message: inputValue }] })
    setInputValue(value);
  };

  const handleCorrespondence = (id: string) => {
    const currentItem = stateChat.find((item) => item.id === id);
    const currentIndex = stateChat.findIndex((item) => item.id === id);
    // const ItemisActive = stateChat.find((item) => item.isActive === true);
    // const IndexItemisActive = stateChat.find((item) => item.isActive === true);

    // console.log(id);
    // console.log(currentIndex);
    // console.log(currentItem);

    return setCorrespondence(
      correspondence
        .slice(0, currentIndex)
        .concat({ ...currentItem })
        .concat(correspondence.slice(currentIndex + 1))
    );
  };

  const handleStateUser = (id: string) => {
    const itemIsActive = stateUser.find((item) => item.isActive === true);
    const indexItemIsActive = stateUser.findIndex((item) => item.isActive === true);
    const currentItem = stateUser.find((item) => item.id === id) || defo;
    const currentIndex = stateUser.findIndex((item) => item.id === id);

    const arr = [0, 1, 2, 3, 4, 5, 6];

    const r= arr.slice(0, 2)
    const w= r..concat(arr.slice(3))




    console.log(w));
    // console.log(stateUser.slice(0, indexItemIsActive), indexItemIsActive);
    // console.log(stateUser.slice(0, indexItemIsActive));
    // console.log({ ...itemIsActive, isActive: false });
    // console.log(stateUser.slice(indexItemIsActive + 1));
    if (!itemIsActive) {
      // console.log(11);
      return setStateUser(
        stateUser
          .slice(0, currentIndex)
          .concat({ ...currentItem, isActive: true })
          .concat(stateUser.slice(currentIndex + 1))
      );
    }
    setStateUser(
      stateUser
        .slice(0, indexItemIsActive)
        .concat({ ...itemIsActive, isActive: false })
        .concat(stateUser.slice(indexItemIsActive + 1))
    );
    // console.log(stateUser[indexItemIsActive].isActive);

    return setStateUser(
      stateUser
        .slice(0, indexItemIsActive)
        .concat({ ...itemIsActive, isActive: false })
        .concat(stateUser.slice(indexItemIsActive + 1))
        .slice(0, currentIndex)
        .concat({ ...currentItem, isActive: true })
        .concat(stateUser.slice(currentIndex + 1))
    );
  };

  const handleSubmit = (event: { preventDefault: () => void }) => {
    event?.preventDefault();
    const currentItem = correspondence[0];
    const currentIndex = 0;
    setCorrespondence(
      correspondence
        .slice(0, currentIndex)
        .concat({ ...currentItem, message: [...currentItem.message, { id: '1u', message: inputValue }] })
        .concat(correspondence.slice(currentIndex + 1))
    );
    setInputValue('');
    // console.log(correspondence);
    // const submitValue = event.currentTarget.children[0].value;
  };

  return (
    <ChatContext.Provider
      value={{
        stateUser,
        correspondence,
        inputValue,
        handleStateUser,
        handleCorrespondence,
        handleChange,
        handleSubmit
      }}
    >
      <WrapperChatPage>
        <LeftContent stateChat={stateUser} />
        <RightContent />
      </WrapperChatPage>
    </ChatContext.Provider>
  );
};
