export const AUTH_TOKEN_FIELD = 'Authorization';
export const API_PREFIX = '/api/graphql';
